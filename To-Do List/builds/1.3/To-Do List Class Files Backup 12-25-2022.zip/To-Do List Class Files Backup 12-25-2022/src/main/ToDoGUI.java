package main;

import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;

/**
 * The main GUI of the program
 * @author James
 * @version 1.3
 */
public class ToDoGUI extends JFrame {

	/**
	 * The version of the GUI
	 */
	public static final String UI_VERSION = "1.3";
	
	private static final long serialVersionUID = 313600793175012718L;

	//The main pane
	private MainPane mainPane;
	
	//The menu items in the window menu
	private JMenuItem helpMenuItem;
	private JMenuItem aboutMenuItem;
	private JMenuItem prefMenuItem;
	
	/**The pop up help window*/
	private MainPane.InfoWindow helpWindow;
	/**The pop up about window*/
	private MainPane.InfoWindow aboutWindow;
	/**The pop up preference window*/
	private MainPane.PrefWindow prefWindow;
	
	/**The window icon*/
	private final ImageIcon windowIcon = new ImageIcon(getClass().getResource("/todoicon.png"));
	/**The center of the screen*/
	private final Point adjustedCenterPoint;
	
	/**
	 * Creates the window
	 */
	public ToDoGUI() {
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(400, 550);
		setTitle("To-Do List");
		setLayout(new BoxLayout(getContentPane(), BoxLayout.X_AXIS));
		setIconImage(windowIcon.getImage());
		//Put the window in the center of the screen
		Point nonAdjustedCenterPoint = GraphicsEnvironment.getLocalGraphicsEnvironment().getCenterPoint();
		adjustedCenterPoint = new Point(nonAdjustedCenterPoint.x - getWidth()/2, nonAdjustedCenterPoint.y - getHeight()/2);
		setLocation(adjustedCenterPoint);
		
		mainPane = new MainPane();
		add(Box.createRigidArea(new Dimension(15, 0)));
		add(mainPane);
		add(Box.createRigidArea(new Dimension(15, 0)));
		
		//The menu bar at the top of the window
		JMenuBar menuBar = new JMenuBar();
		
		//The help menu tab
		JMenu helpMenu = new JMenu("Help");
		helpMenuItem = new JMenuItem("Help");
		helpMenu.add(helpMenuItem);
		aboutMenuItem = new JMenuItem("About");
		helpMenu.add(aboutMenuItem);
		
		//The settings menu tab
		JMenu settingsMenu = new JMenu("Settings");
		prefMenuItem = new JMenuItem("Preferences");
		settingsMenu.add(prefMenuItem);
		
		menuBar.add(helpMenu);
		menuBar.add(settingsMenu);
		
		setJMenuBar(menuBar);
		
		//Initializing all of the pop up windows
		helpWindow = mainPane.new InfoWindow(MainPane.InfoWindow.HelpWindowType.HELP);
		aboutWindow = mainPane.new InfoWindow(MainPane.InfoWindow.HelpWindowType.ABOUT);
		prefWindow = mainPane.new PrefWindow();
		
		addListeners();
		
	}

	/**
	 * Adds listeners to some components, which provides functionality to them
	 */
	private void addListeners() {
		
		//When the program is about to exit, save FileIO's data to the file
		this.addWindowListener(new WindowAdapter() {
			
			@Override
			public void windowClosing(WindowEvent e) {
				
				FileIO.saveToFile();
				System.out.println("saved to file");
				
			}
			
		});
		
		//Help window pop up
		helpMenuItem.addActionListener((e) -> {
			
			helpWindow.setVisible(true);
			helpWindow.setLocation(adjustedCenterPoint);
			
		});
		
		//About window pop up
		aboutMenuItem.addActionListener((e) -> {
			
			aboutWindow.setVisible(true);
			aboutWindow.setLocation(adjustedCenterPoint);
			
		});
		
		//Preferences window pop up
		prefMenuItem.addActionListener((e) -> {
			
			prefWindow.setVisible(true);
			//The OK button should be focused when this window is popped up
			prefWindow.requestOKButtonFocus();
			prefWindow.setLocation(adjustedCenterPoint);
			
		});
		
	}
	
	/**
	 * Reload the look and feel of the pop up windows
	 */
	public void reloadPopupWindows() {
		
		SwingUtilities.updateComponentTreeUI(helpWindow);
		SwingUtilities.updateComponentTreeUI(aboutWindow);
		SwingUtilities.updateComponentTreeUI(prefWindow);
		
	}
	
	//Start the program
	public static void main(String[] args) {

		SwingUtilities.invokeLater(() -> {
			
			//Read the file
			FileIO.readFromFile();
			
			try {
				
				//Set the light or dark mode
				if(FileIO.getUseDarkMode()) {
					
					UIManager.setLookAndFeel(new FlatDarkLaf());
					
				} else {
					
		            UIManager.setLookAndFeel(new FlatLightLaf());
					
				}
				
				//Putting the menu bar below the window header
				UIManager.put("TitlePane.menuBarEmbedded", false);
	            
			} catch (Exception e) {
				
	            e.printStackTrace();
	        
			} 
			
    		ToDoGUI gui = new ToDoGUI();
    		gui.setVisible(true);
    		//The input event text box should be focused when the program starts
    		gui.mainPane.requestEventFieldFocus();
    		
		});
		
	}

}
