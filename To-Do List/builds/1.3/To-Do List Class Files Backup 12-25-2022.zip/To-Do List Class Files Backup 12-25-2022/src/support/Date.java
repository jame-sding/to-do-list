package support;

import java.io.Serializable;
import java.security.InvalidParameterException;
import java.util.Scanner;

/**
 * 
 * A very simple Date class that is merely a container for three integer fields: month, day and year. There are also a few extra methods, as well as enumerated types that represent date formats.<br>
 * <b>Date instances are immutable.</b>
 * 
 * @author James
 *
 */
public class Date implements Comparable<Date>, Serializable {

	public static enum DateFormat {
		MDY {@Override public String toString() {return "MONTH/DAY/YEAR";}}, 
		DMY {@Override public String toString() {return "DAY/MONTH/YEAR";}}, 
		YMD {@Override public String toString() {return "YEAR/MONTH/DAY";}}
	}
	
	private static final long serialVersionUID = -7612517206700521638L;
	
	private final int month;
	private final int day;
	private final int year;
	
	/**
	 * Constructs a date object.
	 * 
	 * @param month Month, 1 representing January and 12 representing December
	 * @param day Day
	 * @param year Year
	 * @throws InvalidParameterException If the parameters make an invalid date.
	 */
	public Date(int month, int day, int year) {

		this.month = month;
		this.day = day;
		this.year = year;
		
		if(!isValidDate(this)) {
			
			throw new InvalidParameterException();
			
		}

	}

	/**
	 * @return The month of this Date object. 1 represents January, and 12 represents December.
	 */
	public int getMonth() {

		return month;

	}

	/**
	 * @return The day of month of this Date object.
	 */
	public int getDay() {

		return day;

	}

	/**
	 * @return The year of this Date object. The year 2020 would be represented as 2020.
	 */
	public int getYear() {

		return year;

	}
	
	@Override
	public String toString() {
		
		return "Day " + day + "; Month " + month + "; Year " + year;
		
	}
	
	/**
	 * When trying to get a user-friendly representation of this Date object, this method should be used instead of the regular <code>toString()</code> method.
	 * 
	 * @param dateFormat The date formatting style to be used
	 * @return A String representation of this object with format specified by <code>dateFormat</code>. Forward slashes "/" are used as separators.
	 */
	public String toString(DateFormat dateFormat) {
		
		switch(dateFormat) {
		
		case DMY:
			return day + "/" + month + "/" + year;
		case MDY:
			return month + "/" + day + "/" + year;
		case YMD:
			return year + "/" + month + "/" + day;
		default:
			throw new UnsupportedOperationException();
		
		}
		
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if(obj != null && obj.getClass().equals(this.getClass()) && ((Date) obj).month == this.month && ((Date) obj).day == this.day && ((Date) obj).year == this.year) {
			
			//The other object is not null, the other object is an Event, and the other object's month, day, and year are the same
			//Note that the order of the boolean expressions in this if statement matters, for example:
			//if the object is null, it would fail the first boolean expression and stop computing the rest of the boolean expressions
			//because the expressions are connected with &&.
			
			return true;
			
		} else {
			
			return false;
			
		}
		
	}
	
	@Override
	public Object clone() {
		
		return new Date(month, day, year);
		
	}
	
	@Override
	public int compareTo(Date o) {
		
		//Note: this method returns 1 if this Date is after the other Date, 0 if this Date is the same as the other Date, and -1 if this Date is before.
		
		if(this.year > o.year) {
			
			//If the year of this Date is larger than the other Date's year, then this Date is definitely after.
			return 1;
			
		} else if(this.year == o.year) {
			
			//The dates share a year.
			
			if(this.month > o.month) {
				
				//If the month of this Date is larger, then this Date is definitely after.
				return 1;
				
			} else if(this.month == o.month) {
				
				//The dates share a month.
				
				if(this.day > o.day) {
					
					//If the day of this Date is larger, then this Date is after.
					return 1;
					
				} else if(this.day == o.day) {
					
					//This Date shares the same day, month, and year with the other Date. They are the same.
					return 0;
					
				}
				
			}
			
		}
		
		//The other Date did not qualify as being after this Date, nor did it qualify for being the same.
		return -1;
		
	}
	
	/**
	 * Reads a String and tries to create a Date object given the intended date format and separators.<br>
	 * The String must express the month, day, and year as integers. Months are from 1-12.
	 * 
	 * @param str A string of month, day, year form separated by spaces and any other specified separator
	 * @param format The intended date format of <code>str</code>
	 * @param separators A list of characters that are intended to separate the month, day and years
	 * @return A Date object parsed from <code>str</code>, null if a date cannot be parsed or if the parsed date was invalid
	 */
	public static Date parse(String str, DateFormat format, char...separators) {
		
		//If there was not a list of separators provided, use the forwards slash and hyphen
		if(separators.length == 0) {
			
			separators = new char[] {'/', '-'};
			
		}
		
		//Replacing the separators with a space (for consistency)
		String dateStr = str;
		for(int i = 0; i < separators.length; i++) {
			
			dateStr = dateStr.replace(separators[i], ' ');
			
		}
		
		//Scanner for dateStr
		Scanner scanner = new Scanner(dateStr);
		
		try {
			
			int month;
			int day;
			int year;
			Date newDate = null;
			
			//The way str will be read depends on the provided date format.
			switch(format) {
			
			//If there are any weird characters in str (ex.: a letter), scanner.nextInt() will throw an exception that will be caught
			
			case DMY:
				day = scanner.nextInt();
				month = scanner.nextInt();
				year = scanner.nextInt();
				newDate = new Date(month, day, year);
				break;
				
			case MDY:
				month = scanner.nextInt();
				day = scanner.nextInt();
				year = scanner.nextInt();
				newDate = new Date(month, day, year);
				break;
				
			case YMD:
				year = scanner.nextInt();
				month = scanner.nextInt();
				day = scanner.nextInt();
				break;
				
			default: //The provided Date Format was not DMY, MDY, or YMD (this can happen if I added a new date format and forgot to implement this for it).
				scanner.close();
				throw new UnsupportedOperationException();
			
			}
			
			//If the code reaches here, then there are no weird characters in str.
			
			if(scanner.hasNext()) {
				
				//There is extra text in str. Such an error wouldn't be caught by the nextInt() methods.
				scanner.close();
				return null;
				
			} else {
				
				//There is no extra text, and there are no weird characters.
				
				scanner.close();
				
				//Finally, if the parsed date is valid, return it. If it isn't valid, return null.
				if(isValidDate(newDate)) {
					
					return newDate;
					
				} else {
					
					return null;
					
				}
				
			}
			
		} catch (Exception e) {
			
			//There was some kind of error when the scanner was doing nextInt().
			//(str might've had extra characters)
			scanner.close();
			return null;
			
		}
		
	}
	
	/**
	 * Checks if a date is valid (exists on the calendar)
	 * @param date The date to check for
	 * @return True if the date is valid
	 */
	public static boolean isValidDate(Date date) {
		
		//If the month isn't between 1 and 12, then the date is invalid (I will still allow negative years though because funny and it still somewhat makes sense)
		if(date.month > 12 || date.month < 1) {
			
			return false;
			
		}
		
		if(date.month == 1 || date.month == 3 || date.month == 5 || date.month == 7 || date.month == 8 || date.month == 10 || date.month == 12) {
			
			//The month is one of the months that have 31 days. Check if the day is in between 1 and 31.
			if(date.day >=1 && date.day <= 31) {
				
				return true;
				
			}
			
		} else {
			
			//The month is one of the months that have less than 31 days. All of these months except for February have 30 days.
			if(date.month != 2) {
				
				//The month is not February, so if the day is in between 1 and 30 it is valid.
				if(date.day >= 1 && date.day <= 30) {
					
					return true;
					
				}
				
			} else {
				
				//The month is February, so check if it is a leap year or not (leap year Februaries have an extra 29th day)
				if(isLeapYear(date.year)) {
					
					//It is a leap year, so if the day is in between 1 and 29 it is valid.
					if(date.day >= 1 && date.day <= 29) {
						
						return true;
						
					}
					
				} else if(date.day >= 1 && date.day <= 28) {
					
					//It wasn't a leap year, but the day is between 1 and 28. It is valid.
					return true;
					
				}
				
			}
			
		}
		
		//The date did not meet any of the qualifications above.
		return false;
		
	}
	
	/**
	 * Checks if a year is a leap year
	 * @param year The year to check for
	 * @return True if <code>year</code> is a leap year
	 */
	public static boolean isLeapYear(int year) {
		
		//Check if the year is divisible by 4
		if(year % 4 != 0) {
			
			//If the year isn't divisible by 4, it is definitely not a leap year.
			return false;
			
		} else if(year % 100 == 0) {
			
			//If the code reaches here, then the year is divisible by 100. This has complications.
			
			//If the year is divisible by 400, it is a leap year. If it is divisible by 100 but not 400, it isn't a leap year.
			//For example, the years 1200, 1600, and 2000 are leap years. 900, 1800, and 1900 aren't.
			if(year % 400 == 0) {
				
				return true;
				
			} else {
				
				return false;
				
			}
			
		} else {
			
			//The year is divisible by 4 but not 100, so it is a leap year.
			return true;
			
		}
		
	}

}
